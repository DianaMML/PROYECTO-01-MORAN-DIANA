if __name__ == "__main__":
  USUARIO = 'dianamoran'
  CONTRASENA = 'proyecto1'
  username = input('Ingrese su nombre de usuario:\n > ')
  password = input('Ingrese la contraseña:\n > ')
  if username == USUARIO:
    if password == CONTRASENA:
      print("Hola! Bienvenido al programa")
    else: 
      print("Contraseña erronea")
  else: 
    print('El usuario no existe')

from lifestore_file import lifestore_products, lifestore_sales, lifestore_searches

#1. De acuerdo a lo solicitado en el punto 1 del proyecto, primero se se obtendrán los productos con mayores y menores vnetas anuales y en seguida una lista con los productos con mayores y menores búsquedas. 

#El primer paso es obtener una lista que contanega el id del producto y el número de ventas.

#Verificamos la longitud de cada lista:

#print (len(lifestore_sales)) = 286
#print (len(lifestore_products)) = 96

#Después se crea una lista vacía a la que se agregará el id de producto y el número de ventas:

prod_ventas = []
cantidad_de_productos = len(lifestore_products)

#Se obtiene el id del producto:

for id in range(cantidad_de_productos):
  verdadero_id = id + 1
  renglon = [verdadero_id, 0]
  prod_ventas.append(renglon)

#Se obtiene el número de ventas:

for venta in lifestore_sales:
  id_prod = venta[1]
  prod_ventas[id_prod - 1][1] = prod_ventas[id_prod - 1][1] + 1

#Modificando los indices en la lista obtenemos los mejores vendidos: 

mejores_vendidos = []
for lista in prod_ventas:
  sublista = lista [1], lista[0]
  mejores_vendidos.append(sublista)

#for ventas in mejores_vendidos:
#  print(ventas)

#Obtenemos los 5 productos mejor vendidos: 

#ganancia_mes.sort(reverse=True)
#print('Ahora en orden mayor a menor de ganancias: ')
#for lista in ganancia_mes:
#  print(lista)

mejores_vendidos.sort(reverse=True)
print('5 productos mejor vendidos: ')
for prod in mejores_vendidos[:5]:
  print(prod)

#Se reordena la lista de menor a mayor para obtener los 5 productos menos vendidos: 

#Es importante mencionar que en el reporte se tomarán en cuenta los productos con al menos una venta, por lo que los productos con cero ventas se descartarán, aunque también se analizará esto en el reporte. 

#Es por esto que se imprimen los primeros 59 elementos. Los últimos 5 son los menos vendidos: 

mejores_vendidos.sort()
print('5 productos menos vendidos: ')
for prod in mejores_vendidos[:59]:
  print(prod)



#Ahora obtendremos los productos con mayores y menores búsquedas:

#Verificamos la longitud de cada lista:

#print (len(lifestore_searches)) = 1033

#Se crea una lista vacía a la que se agregará el id de producto y el número de búsquedas:

prod_busqueda = []
cantidad_de_productos = len(lifestore_products)

#Se obtiene el id del producto:

for id in range(cantidad_de_productos):
  verdadero_id = id + 1
  renglon = [verdadero_id, 0]
  prod_busqueda.append(renglon)

#Se obtiene el número de búsquedas:

for busqueda in lifestore_searches:
  id_prod = busqueda[1]
  prod_busqueda[id_prod - 1][1] = prod_busqueda[id_prod - 1][1] + 1

#print(prod_busqueda) 

#Modificando los indices en la lista obtenemos los más búscados: 

mas_buscados = []
for lista in prod_busqueda:
  sublista = lista [1], lista[0]
  mas_buscados.append(sublista)

#for busquedas in mas_buscados:
#  print(busquedas) 

#Obtenemos los 10 productos más buscados: 

mas_buscados.sort(reverse=True)
print('10 productos más buscados: ')
for prod in mas_buscados[:10]:
  print(prod)
    
#Se reordena la lista de menor a mayor para obtener los 5 productos menos buscados: 

#Es importante mencionar que en el reporte se tomarán en cuenta los productos con al menos una búsqueda, por lo que los productos con cero búsquedas se descartarán, aunque también se analizará esto en el reporte. 

#Es por esto que se imprimen los primeros 50 elementos. Los últimos 10 son los menos buscados: 

mas_buscados.sort()
print('10 productos menos buscados: ')
for prod in mas_buscados[:50]:
    print(prod)

 


 
#2. De acuerdo a lo solicitado en el punto 2 del proyecto, a continuación se obtendran los los productos con  mejores y peores reseñas en el servivio.

#Primero se crea una lista vacía que posteriormente contendrá el id del producto, la suma de las reseñas y la cantidad de ventas:

prod_reseñas = []
for prod in lifestore_products:
    id_prod = prod[0]
    sublista = [id_prod, 0 , 0]
    prod_reseñas.append(sublista)

#Despues se comienza a iterar para obtener el id de producto, suma de las reseñas e índice:

for venta in lifestore_sales:
    id_prod = venta[1]
    reseña = venta[2]
    
    indice = id_prod - 1
    prod_reseñas[indice][1] += reseña
    prod_reseñas[indice][2] += 1

#Ahora vamos a modificar la lista para obtener el id del producto, el promedio de las reseñas y la cantidad de ventas:

for indice, lista in enumerate(prod_reseñas):
   suma = lista[1]
   cantidad = lista[2]
   if cantidad > 0:
       calf_prom = suma / cantidad
       prod_reseñas[indice][1] = calf_prom

#for reseña in prod_reseñas:
#  print(reseña)

#Para obtener los mejores calificados se reordena la lista a continuación:

mejores_calificados = []
for lista in prod_reseñas:
    sublista = [lista[1], lista[0]]
    mejores_calificados.append(sublista)

#Obtenemos los mejores 5 productos mejor reseñados: 

mejores_calificados.sort(reverse=True)
print('5 productos mejor reseñados: ')
for reseña in mejores_calificados[:5]:
    print(reseña)

#Se reordena la lista de menor a mayor para obtener los 5 productos peor reseñados: 

#Es importante mencionar que en el reporte se tomarán en cuenta los productos con al menos una reseña, ya que esto es indicador de que se vendió. Por lo que los productos con cero reseñas se descartarán, aunque también se analizará esto en el reporte. 

#Es por esto que se imprimen los primeros 50 elementos. Los últimos 5 son los peor reseñados: 

mejores_calificados.sort()
print('5 productos peor reseñados: ')
for reseña in mejores_calificados[:59]:
    print(reseña)





#3. De acuerdo a lo solicitado en el punto 3 del proyecto, a continuación se obtendran las ventas mensuales, los meses con más ventas al año,  las ventas promedio mensuales, total anual de ventas y total de ingresos. 

#Primero se limpiarán los datos de las ventas devueltas (rembolso) para obtener sólo  las ventas validas y así obtener las ventas mensuales. Se comienza creadndo una lista vacia:

#Ventas validas:
ventas = []
for sale in lifestore_sales:
    refund = sale[4]    
    if refund == 1:
       continue              
    else:
        ventas.append(sale)

#print(ventas)
#print('Ventas válidas (sin rembolsos): ')
#for venta in ventas:  
#    print(venta)

#Ahora se crea la lista que contendrá los meses y la cantidad de ventas:

meses = [
  '/01/', '/02/', '/03/', '/04/', '/05/', '/06/',
  '/07/', '/08/', '/09/', '/10/', '/11/', '/12/'
  ]
    
ventas_por_mes = []
for mes in meses:
  lista_vacia = []
  ventas_por_mes.append(lista_vacia)

#Se revisa a que mes pertenece cada venta con el siguiente ciclo:
#Se obtienen los datos de la venta id, fecha:

for venta in ventas:
  id_venta = venta[0]
  fecha = venta[3]
  
  # Clasificar por mes:
  contador_de_mes = 0
  
  for mes in meses:
    if mes in fecha:
      ventas_por_mes[contador_de_mes].append(id_venta)
      continue
    contador_de_mes = contador_de_mes + 1 

#print(ventas_por_mes)

contador_de_mes = 0 
print('Ventas por meses: ')          
for venta_mensual in ventas_por_mes:
  print(f'En el mes de {meses[contador_de_mes]} hubo {len(venta_mensual)} ventas')
  contador_de_mes = contador_de_mes + 1

#A continuación se obtendrán una lista con la cantidad de ventas mensuales en relación al mes y posteriormente se ordenará pra obtener los meses con mayores ganancias: 

cantidad_ventas_mensuales = []
for mes, venta_mensual in enumerate(ventas_por_mes):
  cant_ventas_mensuales = len(venta_mensual)
  sublista = [cant_ventas_mensuales, mes]
  cantidad_ventas_mensuales.append(sublista)
  
print('Tabla ventas y mes: ')
for cant in cantidad_ventas_mensuales:
  print(cant)

#Después se reordena la lista para obtener los meses con mayores ventas:

cantidad_ventas_mensuales.sort(reverse=True)
print('Meses con mayores ventas: ')
for par in cantidad_ventas_mensuales:
  print(par)

#Ahora se encontrarán los ingresos de cada mes:

ganancias_mensuales = []
for venta_mensual in ventas_por_mes:
  ganancia_del_mes = 0
  for id_venta in venta_mensual:
    indice_de_venta = id_venta - 1
    info_de_venta = lifestore_sales[indice_de_venta]
    
    id_prod = info_de_venta[1]
    indice_de_prod = id_prod - 1
    info_del_prod = lifestore_products[indice_de_prod]
    precio_de_prod = info_del_prod[2]
    ganancia_del_mes = ganancia_del_mes + precio_de_prod
  
  ganancias_mensuales.append(ganancia_del_mes)

#print(ganancias_mensuales)  

#El siguiente paso es sumar todas las ganancias para obtener el total anual de ganancias: 

print('Total anual de ganancias: ')
total_ganancias = sum(ganancias_mensuales)
print(total_ganancias)

#Despues se divide el total de ganancias entre 12 (meses) para obtener el promedio mensual de ganancias: 

print('Promedio mensual de ganancias: ')
promedio_mensual_ganancias = total_ganancias/len(ganancias_mensuales)
print(promedio_mensual_ganancias)

#A continuación se ordena la lista que contiene las ganancias mensuales y se agrega el mes al que pertence cada monto:

ganancia_mes = []
for mes, ganancia in enumerate(ganancias_mensuales):
  sublista = [ganancia, mes]
  ganancia_mes.append(sublista)

#Se imprime la lista con las ganacias por mes: 

print('Ganancias mensuales: ')
for lista in ganancia_mes:
  print(lista)

#Se imprime la lista con los meses de mayores a menores ganancias: 

ganancia_mes.sort(reverse=True)
print('Meses con mayores ganancias: ')
for lista in ganancia_mes:
  print(lista)
